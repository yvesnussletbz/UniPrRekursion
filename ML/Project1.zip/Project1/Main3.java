import java.util.Scanner;

public class Main3
{
    public static void main(String[] args)
    {
        Menu(-1);
        System.out.println("Danke f�r den Besuch.");
    }
    
    public static void Menu(int menuNumber) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("----------------------------------");
		System.out.println("Rekursion starten:");
		System.out.println("1: Fibonnaci:");
		System.out.println("2: Fakult�t:");
		System.out.println("3: GGT:");
		System.out.println("4: Divide And Conquer:");
		System.out.println("0: Exit:");
		int result = Integer.parseInt(scanner.nextLine());
		switch (result) {
			case 1:
				(new Fibonacci()).Run(10);
				break;
			case 2:
				(new Faculty()).Run(10);
				break;
			case 3:
				(new GGT()).Run(15, 25);
				break;
			case 4:
				(new DivideAndConquer()).Run(30);
				break;
		}
		if (result == 0)
			return;
		Menu(result);
    }
}
