import java.util.Scanner;
// Dienste
/**
 * @author
 * @version
 */
public class Main
{

    // Bezugsobjekte
    // Attribute
    // Konstruktor
    public static void main(String[] args)
    {
        int result = 0;
        do {
            Scanner scanner = new Scanner(System.in);
            System.out.println("----------------------------------");
            System.out.println("Rekursion starten:");
            System.out.println("1: Fibonnaci:");
            System.out.println("2: Fakult�t:");
            System.out.println("3: GGT:");
            System.out.println("4: Divide And Conquer:");
            System.out.println("5: BinarySearch:");
            System.out.println("6: Quicksort:");
            System.out.println("0: Exit:");
            result = Integer.parseInt(scanner.nextLine());
            switch (result) {
                case 1: (new Fibonacci()).Run(10); break;
                case 2: (new Faculty()).Run(10); break;
                case 3: (new GGT()).Run(15, 25); break;
                case 4: (new DivideAndConquer()).Run(13); break;
                case 5: (new BinarySearch()).Run(new int[]{ 2, 3, 4, 10, 40, 45 }, 10); break;
                case 6: (new QuickSort()).Run(new int[] {4, 8, 1, 10, 13, 5, 2, 7}); break;
            }
        } while(result != 0);

        System.out.println("Danke f�r den Besuch.");
    }

}
