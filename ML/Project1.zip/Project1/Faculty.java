public class Faculty {
    public void Run(int n){
        System.out.println("Fakult�t von " + n + ": " + Fac(n));
    }

    private int Fac(int n){
        if (n == 1)
            return 1;
        else {
            return Fac(n-1)*n;
        }
    }
}
