
public class DivideAndConquer {
    private char[] list;

    public void Run(int n){
        list = new char[n];
        java.util.Arrays.fill(list, '-');
       
        DaC(0, list.length-1);
//        System.out.println(list);
    }

    private void DaC(int from, int to){
        if (from >= to){
            try{
                Thread.sleep(500);
            }
            catch(Exception e){}
            list[from] = 'X';
            System.out.println(list);
        }
        else {
            int middle = (to - from)/2;
            DaC(from, from+middle);
            DaC(from+middle+1, to);
        }
    }
}