public class GGT {
    public void Run(int a, int b){
        System.out.println("GGT von " + a + " und " + b + " ist: " + Ggt(a,b));
    }


    private int Ggt(int a, int b){
        if (a == b)
            return a;
        else {
            if (a > b)
                return Ggt(b, a-b);
            else
                return Ggt(a, b-a);
        }
    }
}
