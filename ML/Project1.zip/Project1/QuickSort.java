
public class QuickSort {
    private char[] list;

    public void Run(int[] unsorted){
        print(unsorted);
        Sort(unsorted, 0, unsorted.length - 1); 
    }

    private void Sort(int[] arr, int low, int high){
        print(arr);
        if(low < high){
            int p = Partition(arr, low, high);
            Sort(arr, low, p-1);
            Sort(arr, p+1, high);
        }
    }
    
    private void Swap(int[] arr, int low, int pivot){
        int tmp = arr[low];
        arr[low] = arr[pivot];
        arr[pivot] = tmp;
    }
    
    private int Partition(int[] arr, int low, int high){
        int p = low, j;
        for(j=low+1; j <= high; j++)
            if(arr[j] < arr[low])
                Swap(arr, ++p, j);

        Swap(arr, low, p);
        return p;
    }
    
    private void print(int[]  arr) {
        for(int i=0; i<=arr.length-1; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }
}