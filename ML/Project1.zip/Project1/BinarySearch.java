
public class BinarySearch {
    private char[] list;

    public void Run(int[] sorted, int toFind){
        print(sorted);
        int index = Find(sorted, 0, sorted.length - 1, toFind); 
        System.out.println("Werte gefunden an position: " + index);
    }

    private int Find(int arr[], int l, int r, int x){
        if (r >= l) {
            int mid = l + (r - l) / 2;
 
            if (arr[mid] == x)
                return mid;

            if (arr[mid] > x)
                return Find(arr, l, mid - 1, x);
            else 
                return Find(arr, mid + 1, r, x);
        }
        return -1;
    }
   
    
    private void print(int[]  arr) {
        for(int i=0; i<=arr.length-1; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }
}