import javakara.JavaKaraProgram;

public class Rekursiv extends JavaKaraProgram {

  public void myProgram() {
    world.clearAll();
    kara.setPosition(0,0);

    Move(1,0);
    
  }

	public void Move(int direction, int y){
		if (y >= world.getSizeY()) return;
		else {
			for (int i=0; i< world.getSizeX()-1; i++) {
				kara.putLeaf();
				kara.move();
			}
			if (direction == 1) {
				kara.turnRight();
				kara.putLeaf();
				kara.move();
				kara.turnRight();
			}
			else {
				kara.turnLeft();
				kara.putLeaf();
				kara.move();
				kara.turnLeft();
			} 
			Move(direction*-1, y++);
		}
	}
}

        