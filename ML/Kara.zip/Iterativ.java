import javakara.JavaKaraProgram;
        
public class Iterativ extends JavaKaraProgram {

  public void myProgram() {
    world.clearAll();
    kara.setPosition(0,0);
    int direction = 1;

    for (int j=0; j < world.getSizeY(); j++) {
      for (int i=0; i< world.getSizeX()-1; i++) {
        kara.putLeaf();
        kara.move();
      }

      if (direction == 1) {
        kara.turnRight();
        kara.putLeaf();
        kara.move();
        kara.turnRight();
      }
      else {
        kara.turnLeft();
        kara.putLeaf();
        kara.move();
        kara.turnLeft();
      }
      direction = direction * -1;
    }
  }
}

        